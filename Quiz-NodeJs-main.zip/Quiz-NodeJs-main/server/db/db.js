const mongoose = require("mongoose");

const connect = async () => {
  await mongoose
    .connect("mongodb+srv://kamal1270:kamal1270@cluster0.bhmlocn.mongodb.net/QuizApp?retryWrites=true&w=majority")
    .then(() => {
      console.log("Database connected ");
    })
    .catch((err) => {
      console.log(err);
    });
};

module.exports = connect;
